<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'bu', 'zhang', 'lei', 'qiang', 'man', 'yan', 'ling', 'ji', 'biao', 'gun', 'han', 'di', 'su', 'lu', 'she', 'shang',
  0x10 => 'di', 'mie', 'xun', 'man', 'bo', 'di', 'cuo', 'zhe', 'shen', 'xuan', 'wei', 'hu', 'ao', 'mi', 'lou', 'cu',
  0x20 => 'zhong', 'cai', 'po', 'jiang', 'mi', 'cong', 'niao', 'hui', 'juan', 'yin', 'jian', 'nian', 'shu', 'yin', 'guo', 'chen',
  0x30 => 'hu', 'sha', 'kou', 'qian', 'ma', 'zang', 'ze', 'qiang', 'dou', 'lian', 'lin', 'kou', 'ai', 'bi', 'li', 'wei',
  0x40 => 'ji', 'qian', 'sheng', 'fan', 'meng', 'ou', 'chan', 'dian', 'xun', 'jiao', 'rui', 'rui', 'lei', 'yu', 'qiao', 'chu',
  0x50 => 'hua', 'jian', 'mai', 'yun', 'bao', 'you', 'qu', 'lu', 'rao', 'hui', 'e', 'ti', 'fei', 'jue', 'zui', 'fa',
  0x60 => 'ru', 'fen', 'kui', 'shun', 'rui', 'ya', 'xu', 'fu', 'jue', 'dang', 'wu', 'dong', 'si', 'xiao', 'xi', 'long',
  0x70 => 'wen', 'shao', 'qi', 'jian', 'yun', 'sun', 'ling', 'yu', 'xia', 'weng', 'ji', 'hong', 'si', 'nong', 'lei', 'xuan',
  0x80 => 'yun', 'yu', 'xi', 'hao', 'bao', 'hao', 'ai', 'wei', 'hui', 'hui', 'ji', 'ci', 'xiang', 'wan', 'mie', 'yi',
  0x90 => 'leng', 'jiang', 'can', 'shen', 'qiang', 'lian', 'ke', 'yuan', 'da', 'ti', 'tang', 'xue', 'bi', 'zhan', 'sun', 'xian',
  0xA0 => 'fan', 'ding', 'xie', 'gu', 'xie', 'shu', 'jian', 'hao', 'hong', 'sa', 'xin', 'xun', 'yao', 'bai', 'sou', 'shu',
  0xB0 => 'xun', 'dui', 'pin', 'wei', 'ning', 'chou', 'mai', 'ru', 'piao', 'tai', 'ji', 'zao', 'chen', 'zhen', 'er', 'ni',
  0xC0 => 'ying', 'gao', 'cong', 'xiao', 'qi', 'fa', 'jian', 'xu', 'kui', 'ji', 'bian', 'diao', 'mi', 'lan', 'jin', 'cang',
  0xD0 => 'miao', 'qiong', 'qie', 'xian', 'liao', 'ou', 'xian', 'su', 'lu', 'yi', 'xu', 'xie', 'li', 'yi', 'la', 'lei',
  0xE0 => 'jiao', 'di', 'zhi', 'bei', 'teng', 'yao', 'mo', 'huan', 'biao', 'fan', 'sou', 'tan', 'tui', 'qiong', 'qiao', 'wei',
  0xF0 => 'liu', 'hui', 'ou', 'gao', 'yun', 'bao', 'li', 'shu', 'chu', 'ai', 'lin', 'zao', 'xuan', 'qin', 'lai', 'huo',
];
